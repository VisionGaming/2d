addLevel(
	{
		name:"Danielle 1",
		levelData:{"man":{"row":2,"column":18},"tileArray":[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,-1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,1,1,1,null,null,null,1,1,1,1,1,1,1,1,1,1,1,1,1,null,1,1,1,1,1,null,null,null,null,null,-1,-1,-1,null,null,null,null,1,1,1,1,1,1,1,1,1,-1,null,null,null,null,null,null,null,null,null,null,null,null,null,1,-1,-1,-1,-1,1,1,null,-1,-1,-1,null,-1,null,null,null,null,null,null,1,1,1,4,4,4,4,1,1,-1,1,1,null,1,-1,null,null,null,null,1,1,1,1,5,5,5,5,5,1,3,1,1,null,1,1,1,-1,1,1,1,1,1,1,5,5,5,5,5,1,1,1,null,null,null,null,1,null,null,null,null,null,1,1,5,5,5,5,1,1,null,null,null,null,null,0,1,1,1,1,1,null,1,1,5,1,1,1,1,-1,null,null,null,null,-1,1,1,null,null,null,1,null,1,1,5,5,5,5,1,null,null,2,2,-1,2,1,null,null,null,null,1,null,1,1,1,1,1,5,1,2,-1,null,null,null,-1,null,null,null,null,null,1,null,1,1,4,4,1,5,1,null,2,-1,null,null,null,null,null,null,null,null,1,null,1,1,5,5,1,5,1,null,null,2,-1,-1,null,null,null,null,null,null,1,null,1,1,5,5,1,5,1,null,null,null,2,-1,2,2,2,2,null,null,1,null,1,1,5,5,1,5,-1,null,null,null,null,null,null,null,null,null,-1,null,null,null,1,1,5,5,1,5,4,2,null,null,null,null,null,null,null,null,2,null,null,null,1,1,5,5,5,5,5,1,2,null,null,3,null,null,null,null,null,null,null,null,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],"objectArray":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":8,"transDex":0},{"objectDex":2,"transDex":1},null,null,{"objectDex":2,"transDex":2},{"objectDex":2,"transDex":3},{"objectDex":2,"transDex":4},{"objectDex":2,"transDex":5},{"objectDex":2,"transDex":6},{"objectDex":2,"transDex":7},{"objectDex":2,"transDex":8},{"objectDex":2,"transDex":9},{"objectDex":2,"transDex":10},{"objectDex":2,"transDex":11},{"objectDex":2,"transDex":12},{"objectDex":2,"transDex":13},{"objectDex":2,"transDex":14},null,null,null,null,{"objectDex":2,"transDex":15},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":12,"transDex":16},null,null,null,{"objectDex":2,"transDex":17},{"objectDex":2,"transDex":18},{"objectDex":2,"transDex":19},{"objectDex":2,"transDex":20},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":4,"transDex":21},null,{"objectDex":0,"transDex":22},{"objectDex":2,"transDex":23},{"objectDex":2,"transDex":24},{"objectDex":2,"transDex":25},null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":14,"transDex":26},null,null,null,{"objectDex":10,"transDex":27},{"objectDex":10,"transDex":28},{"objectDex":10,"transDex":29},{"objectDex":10,"transDex":30},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":14,"transDex":31},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":6,"transDex":32},null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":33},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":34},{"objectDex":2,"transDex":35},null,{"objectDex":2,"transDex":36},null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":37},{"objectDex":2,"transDex":38},{"objectDex":2,"transDex":39},{"objectDex":2,"transDex":40},null,{"objectDex":2,"transDex":41},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":42},null,null,{"objectDex":2,"transDex":43},null,null,null,null,{"objectDex":2,"transDex":44},{"objectDex":2,"transDex":45},null,null,null,null,null,null,null,{"objectDex":10,"transDex":46},{"objectDex":10,"transDex":47},null,{"objectDex":2,"transDex":48},null,null,null,{"objectDex":2,"transDex":49},null,null,null,{"objectDex":2,"transDex":50},{"objectDex":2,"transDex":51},null,null,null,null,null,null,null,null,{"objectDex":12,"transDex":52},null,{"objectDex":2,"transDex":53},null,null,null,null,{"objectDex":2,"transDex":54},null,{"objectDex":2,"transDex":55},null,null,{"objectDex":2,"transDex":56},null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":57},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":58},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":10,"transDex":59}]},
		// instances of baddies in level3 (Dani level)
		baddieInstance:[
			{
				name: "bat", moveType: "pointChaser", loop: true, points:500, facing:"left", speed:4, healthDecrement:2,
				moveArray: [
					{ x: 10, y: 3},
					{ x: 10, y: 18}
				],
				spawn:{
					name:"turd_drop", 
					relativeX:32, 
					relativeY:32, 
					frameDelay:10,
					maxInPlay:3,
					healthDecrement:1,
					condition:"Drop from above"
				}
			},
			{name: "silo_tiny_left", moveType: "pointChaser", loop: true, points:300, facing:"left", speed:0, healthDecrement:10,
				moveArray: [
					{ x: 15, y: 3},
					{ x: 15, y: 3}
				],
				spawn:{
					name:"exocet_tiny", 
					relativeX:0, 
					relativeY:5, 
					frameDelay:3,
					maxInPlay:1,
					healthDecrement:10,
					condition:"Launch from right"
				}
			},
			{
				name: "bat", moveType: "pointChaser", loop: true, points:500, facing:"left", speed:4, healthDecrement:2,
				moveArray: [
					{ x: 10, y: 3},
					{ x: 10, y: 18}
				],
				spawn:{
					name:"turd_drop", 
					relativeX:32, 
					relativeY:32, 
					frameDelay:10,
					maxInPlay:3,
					healthDecrement:1,
					condition:"Drop from above"
				}
			},		
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:8, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 1, y: 6},
					{ x: 4, y: 6},
					{ x: 1, y: 9},
					{ x: 4, y: 9},
					{ x: 3, y: 8}
				],
				spawn: {}
			},		
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:8, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 1, y: 13},
					{ x: 2, y: 18},
					{ x: 2, y: 18},
					{ x: 2, y: 18}
				],
				spawn: {}
			},
			{
				name: "jellyfish", moveType: "pointChaser", loop: true, points:750, facing:"left", speed:4, healthDecrement:3,
				moveArray: [
					{ x: 1, y: 10},
					{ x: 1, y: 11},
					{ x: 4, y: 11},
					{ x: 4, y: 18},
					{ x: 2, y: 18},
					{ x: 1, y: 13},
					{ x: 1, y: 13},
					{ x: 2, y: 13},
					{ x: 1, y: 13}

				],
				spawn: {}
			},
			{
				name: "rock", moveType: "pointChaser", loop: true, points:750, facing:"down", speed:4, healthDecrement:3,
				moveArray: [
					{ x: 16, y: 10},
					{ x: 16, y: 10}
				],
				spawn:{
					name:"rock_falling", 
					killsBaddieInstance:true,
					relativeX:0, 
					relativeY:32, 
					frameDelay:3,
					maxInPlay:1,
					healthDecrement:10,
					condition:"Drop from above"
				}
			},
			{
				name: "rock", moveType: "pointChaser", loop: true, points:750, facing:"down", speed:4, healthDecrement:3,
				moveArray: [
					{ x: 15, y: 10},
					{ x: 15, y: 10}
				],
				spawn:{
					name:"rock_falling", 
					killsBaddieInstance:true,
					relativeX:0, 
					relativeY:32, 
					frameDelay:3,
					maxInPlay:1,
					healthDecrement:10,
					condition:"Drop from above"
				}
			},
			{
				name: "rock", moveType: "pointChaser", loop: true, points:750, facing:"down", speed:4, healthDecrement:3,
				moveArray: [
					{ x: 14, y: 10},
					{ x: 14, y: 10}
				],
				spawn:{
					name:"rock_falling", 
					killsBaddieInstance:true,
					relativeX:0, 
					relativeY:32, 
					frameDelay:3,
					maxInPlay:1,
					healthDecrement:10,
					condition:"Drop from above"
				}
			}
		],
		platforms:[
			{
				name: "conveyor1", 
				spriteSheet:"platform2", frameInterval:2,
				loop: true,  speed:8, scaling:100, xPadding:15,
				moveArray: [
					{ x: 18, y: 9},
					{ x: 18, y: 19}
				]
			}
		]
	}
);