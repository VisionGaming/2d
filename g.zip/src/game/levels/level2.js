addLevel(
	{
		name:"Zac 1",
		levelData:{"man":{"row":1,"column":0},"tileArray":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,1,1,1,1,1,1,null,null,1,1,1,1,1,1,1,1,1,1,1,1,-1,-1,-1,-1,1,-1,null,null,-1,1,null,null,null,null,null,null,null,null,null,null,-1,-1,-1,-1,1,-1,null,null,-1,1,null,null,null,null,null,null,null,null,null,null,1,-1,-1,-1,1,1,null,null,1,1,1,null,null,1,1,1,1,1,1,1,1,1,-1,-1,-1,1,null,null,1,1,1,1,null,null,null,null,null,null,null,null,1,1,1,-1,-1,1,null,null,1,1,1,1,1,null,null,null,null,null,null,null,1,1,1,1,-1,1,-1,-1,1,1,1,1,1,1,null,null,null,null,null,null,4,4,4,4,4,4,4,4,1,1,1,1,1,1,1,4,4,4,4,4,5,5,5,5,5,5,5,5,1,5,5,5,5,5,5,5,5,6,6,6,5,5,5,5,5,5,5,5,1,5,5,5,5,5,5,1,1,1,1,1,5,5,5,5,5,5,5,5,1,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,1,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,1,5,5,5,5,5,5,5,5,5,5,5,5,5,5,1,1,1,1,1,1,1,1,1,1,1,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,1,5,5,5,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,1,1,1,1,1,5,5,5,6,6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],"objectArray":[null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":0},{"objectDex":2,"transDex":1},{"objectDex":2,"transDex":2},{"objectDex":2,"transDex":3},{"objectDex":2,"transDex":4},{"objectDex":2,"transDex":5},{"objectDex":2,"transDex":6},{"objectDex":2,"transDex":7},{"objectDex":2,"transDex":8},{"objectDex":2,"transDex":9},{"objectDex":2,"transDex":10},null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":11},{"objectDex":2,"transDex":12},{"objectDex":2,"transDex":13},{"objectDex":2,"transDex":14},{"objectDex":2,"transDex":15},{"objectDex":2,"transDex":16},{"objectDex":2,"transDex":17},{"objectDex":2,"transDex":18},{"objectDex":2,"transDex":19},{"objectDex":2,"transDex":20},{"objectDex":2,"transDex":21},null,null,null,null,null,{"objectDex":7,"transDex":22},null,null,{"objectDex":7,"transDex":23},null,null,null,null,null,null,null,null,null,null,null,{"objectDex":12,"transDex":24},{"objectDex":2,"transDex":25},{"objectDex":2,"transDex":26},{"objectDex":2,"transDex":27},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":0,"transDex":28},{"objectDex":2,"transDex":29},{"objectDex":2,"transDex":30},{"objectDex":2,"transDex":31},{"objectDex":2,"transDex":32},null,{"objectDex":4,"transDex":33},null,null,{"objectDex":8,"transDex":34},null,null,null,null,{"objectDex":2,"transDex":35},{"objectDex":2,"transDex":36},{"objectDex":2,"transDex":37},{"objectDex":2,"transDex":38},{"objectDex":2,"transDex":39},{"objectDex":2,"transDex":40},{"objectDex":2,"transDex":41},null,{"objectDex":2,"transDex":42},{"objectDex":2,"transDex":43},{"objectDex":2,"transDex":44},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":45},{"objectDex":2,"transDex":46},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":47},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":10,"transDex":48},{"objectDex":10,"transDex":49},{"objectDex":10,"transDex":50},{"objectDex":10,"transDex":51},{"objectDex":10,"transDex":52},{"objectDex":10,"transDex":53},{"objectDex":10,"transDex":54},{"objectDex":10,"transDex":55},null,null,null,null,null,null,null,{"objectDex":10,"transDex":56},{"objectDex":10,"transDex":57},{"objectDex":10,"transDex":58},{"objectDex":10,"transDex":59},{"objectDex":10,"transDex":60},null,null,null,null,null,null,null,null,null,{"objectDex":12,"transDex":61},{"objectDex":2,"transDex":62},{"objectDex":2,"transDex":63},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":64},{"objectDex":2,"transDex":65},{"objectDex":2,"transDex":66},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":67},{"objectDex":2,"transDex":68},{"objectDex":2,"transDex":69},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":6,"transDex":70},null,null,null,{"objectDex":2,"transDex":71},{"objectDex":2,"transDex":72},{"objectDex":2,"transDex":73},{"objectDex":2,"transDex":74},{"objectDex":2,"transDex":75},{"objectDex":2,"transDex":76},{"objectDex":2,"transDex":77},{"objectDex":2,"transDex":78},{"objectDex":2,"transDex":79},{"objectDex":2,"transDex":80},{"objectDex":2,"transDex":81},null,null,{"objectDex":2,"transDex":82},{"objectDex":2,"transDex":83},{"objectDex":2,"transDex":84},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,{"objectDex":2,"transDex":85},{"objectDex":2,"transDex":86},{"objectDex":2,"transDex":87},{"objectDex":2,"transDex":88},{"objectDex":14,"transDex":89},null,null,null,null,null]},
		// instances of baddies in level0
		baddieInstance:[
			{
				name: "bat", moveType: "roamingLeft", loop: true, points:500, facing:"left", speed:4, healthDecrement:2,
				moveArray: [
					{ x: 3, y: 3}
				],
				spawn:{
					name:"turd_drop", 
					relativeX:32, 
					relativeY:32, 
					frameDelay:10,
					maxInPlay:3,
					healthDecrement:1,
					condition:"Drop from above"
				}
			},
			{
				name: "fish", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:2, notDie:true, notKill:true,
				moveArray: [
					{ x: 19, y: 9},
					{ x: 16, y: 9},
					{ x: 9, y: 14},
					{ x: 13, y: 14}
				],
				spawn: {}
			},
			{
				name: "shark_large", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:8, notDie:false, notKill:false,
				healthDecrement:7,
				moveArray: [
					{ x: 6, y: 9},
					{ x: 0, y: 9},
					{ x: 6, y: 14},
					{ x: 0, y: 14}
				],
				spawn: {}
			},
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:2, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 0, y: 14},
					{ x: 7, y: 14},
					{ x: 0, y: 9},
					{ x: 7, y: 9}
				],
				spawn: {}
			},
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:2, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 9, y: 10},
					{ x: 18, y: 15},
					{ x: 9, y: 14},
					{ x: 18, y: 12}
				],
				spawn: {}
			},
			{
				name: "shark_large", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:8, notDie:false, notKill:false,
				healthDecrement:7,
				moveArray: [
					{ x: 9, y: 10},
					{ x: 10, y: 11},
					{ x: 15, y: 12},
					{ x: 18, y: 12},
					{ x: 9, y: 12},
					{ x: 18, y: 14},
					{ x: 9, y: 14},
					{ x: 15, y: 12}
				],
				spawn: {}
			},
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:2, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 14, y: 18},
					{ x: 0, y: 16},
					{ x: 14, y: 16},
					{ x: 0, y: 18}
				],
				spawn: {}
			},
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:4, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 0, y: 17},
					{ x: 14, y: 17},
					{ x: 0, y: 16},
					{ x: 14, y: 16}
				],
				spawn: {}
			},		
			{
				name: "shark_small", moveType: "pointChaser", loop: true, points:1000, facing:"left", speed:8, notDie:false, notKill:false,
				healthDecrement:3,
				moveArray: [
					{ x: 0, y: 17},
					{ x: 14, y: 17},
					{ x: 0, y: 16},
					{ x: 18, y: 18},
					{ x: 14, y: 18}
				],
				spawn: {}
			}			

		],


		platforms:[
		]
	}
);